# JARVIS v0.2 (Sinhala + English voice assistant)

Say "Jarvis" / "ජාවිස්" -> JARVIS answers "Hi <your name>" -> give a command in Sinhala or English.

Built-in commands (no AI needed): call <contact/number>, open <app>, YouTube search, time. Everything else goes to the AI.

## Build the APK without Android Studio
Push this folder to a GitHub repo -> Actions tab -> "Build APK" -> download artifact JARVIS-apk (app-debug.apk).

## Or with Android Studio
Open folder -> Build > Build APK(s).
