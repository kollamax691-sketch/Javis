package com.jarvis.starter

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Actions the AI can trigger (function calling). */
object Tools {
    private fun fn(name: String, desc: String, vararg p: String): JSONObject {
        val props = JSONObject(); val req = JSONArray()
        for (s in p) { val (k, t) = s.split(":"); props.put(k, JSONObject().put("type", t)); req.put(k) }
        return JSONObject().put("type", "function").put("name", name).put("description", desc)
            .put("parameters", JSONObject().put("type", "object").put("properties", props)
                .put("required", req).put("additionalProperties", false))
    }

    fun defs() = JSONArray()
        .put(fn("call", "Phone call a contact name or number.", "who:string"))
        .put(fn("send_sms", "Send an SMS text message directly.", "to:string", "message:string"))
        .put(fn("send_whatsapp", "Open WhatsApp chat with message prefilled (user taps send). Number may be local Sri Lankan.", "to:string", "message:string"))
        .put(fn("open_app", "Open an installed app by name.", "name:string"))
        .put(fn("youtube", "Search/play something on YouTube.", "query:string"))
        .put(fn("web_search", "Google search in browser.", "query:string"))
        .put(fn("navigate", "Start map navigation to a place.", "place:string"))
        .put(fn("set_alarm", "Set an alarm at 24h hour and minute.", "hour:integer", "minute:integer", "label:string"))
        .put(fn("set_timer", "Start a countdown timer / reminder in seconds.", "seconds:integer", "label:string"))
        .put(fn("flashlight", "Turn flashlight on or off.", "on:boolean"))
        .put(fn("volume", "Change media volume. action is one of: up, down, mute, max.", "action:string"))
        .put(fn("media", "Control playing media. action is one of: play_pause, next, previous, stop.", "action:string"))
        .put(fn("battery", "Get battery percentage and charging state."))
        .put(fn("date_time", "Get current date and time."))

    private fun num(ctx: Context, s: String): String? {
        val d = s.replace(Regex("[\\s-]"), "")
        return if (d.matches(Regex("\\+?\\d{3,}"))) d else Brain.findNumber(ctx, s)
    }

    private fun go(ctx: Context, i: Intent) = Brain.launch(ctx, i)

    fun run(ctx: Context, name: String, a: JSONObject): String = try {
        when (name) {
            "call" -> Brain.handle(ctx, "call " + a.getString("who")) ?: "failed"
            "send_sms" -> {
                val n = num(ctx, a.getString("to")) ?: return "Contact not found"
                if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
                    return "SMS permission not granted"
                val sm = ctx.getSystemService(SmsManager::class.java)
                sm.sendMultipartTextMessage(n, null, sm.divideMessage(a.getString("message")), null, null)
                "SMS sent"
            }
            "send_whatsapp" -> {
                var n = num(ctx, a.getString("to")) ?: return "Contact not found"
                n = n.removePrefix("+"); if (n.startsWith("0")) n = "94" + n.drop(1)
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + Uri.encode(a.getString("message")))))
                "WhatsApp opened with the message; user must tap send"
            }
            "open_app" -> Brain.handle(ctx, "open " + a.getString("name")) ?: "App not found"
            "youtube" -> Brain.handle(ctx, "youtube " + a.getString("query")) ?: "failed"
            "web_search" -> { go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query"))))); "Opened" }
            "navigate" -> { go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(a.getString("place"))))); "Navigation started" }
            "set_alarm" -> {
                go(ctx, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "Alarm set"
            }
            "set_timer" -> {
                go(ctx, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "Timer started"
            }
            "flashlight" -> {
                val cm = ctx.getSystemService(CameraManager::class.java)
                cm.setTorchMode(cm.cameraIdList.first(), a.getBoolean("on")); "Done"
            }
            "volume" -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val s = AudioManager.STREAM_MUSIC
                when (a.getString("action")) {
                    "up" -> am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    "down" -> am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    else -> am.setStreamVolume(s, am.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI)
                }
                "Done"
            }
            "media" -> {
                val code = when (a.getString("action")) {
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "stop" -> KeyEvent.KEYCODE_MEDIA_STOP; else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                val am = ctx.getSystemService(AudioManager::class.java)
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code)); "Done"
            }
            "battery" -> {
                val b = ctx.getSystemService(BatteryManager::class.java)
                "${b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%, charging=${b.isCharging}"
            }
            "date_time" -> SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.US).format(Date())
            else -> "Unknown tool"
        }
    } catch (e: Exception) { "Failed: ${e.message}" }
}
