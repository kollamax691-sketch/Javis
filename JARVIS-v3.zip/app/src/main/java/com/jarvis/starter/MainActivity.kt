package com.jarvis.starter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var logText: TextView
    private lateinit var toggle: Button
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { onClick() }
    }

    private fun field(hintText: String, key: String, def: String, secret: Boolean = false) =
        EditText(this).apply {
            hint = hintText; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setText(prefs.getString(key, def))
            inputType = InputType.TYPE_CLASS_TEXT or (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else 0)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(5, 7, 13))
        }
        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S."; textSize = 30f; setTextColor(Color.rgb(0, 200, 255))
            gravity = android.view.Gravity.CENTER
        })
        val name = field("Your name", "name", "Niroshan")
        val key = field("OpenAI API key", "key", "", true)
        val model = field("AI model", "model", OpenAIClient.DEFAULT_MODEL)
        root.addView(name); root.addView(key); root.addView(model)

        root.addView(btn("SAVE SETTINGS") {
            prefs.edit().putString("name", name.text.toString().trim())
                .putString("key", key.text.toString().trim())
                .putString("model", model.text.toString().trim()).apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("COMMAND LANGUAGE: " + langLabel()) { }.also { b ->
            b.setOnClickListener {
                val next = if (prefs.getString("lang", "si-LK") == "si-LK") "en-US" else "si-LK"
                prefs.edit().putString("lang", next).apply(); b.text = "COMMAND LANGUAGE: " + langLabel()
            }
        })
        root.addView(btn("1) GRANT PERMISSIONS") { askPermissions() })
        root.addView(btn("2) ALLOW DISPLAY OVER OTHER APPS") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        toggle = btn("") { toggleService() }
        root.addView(toggle)
        logText = TextView(this).apply { textSize = 16f; setTextColor(Color.WHITE); setPadding(0, 24, 0, 0) }
        root.addView(logText)
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.rgb(5, 7, 13)); addView(root) })
    }

    private fun langLabel() = if (prefs.getString("lang", "si-LK") == "si-LK") "සිංහල" else "English"

    private fun toggleService() {
        val i = Intent(this, JarvisService::class.java)
        if (JarvisService.running) { stopService(i); JarvisService.running = false }
        else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                askPermissions(); return
            }
            startForegroundService(i)
        }
        refresh()
    }

    private fun askPermissions() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }

    private fun refresh() { toggle.text = if (JarvisService.running) "■ STOP JARVIS" else "▶ START JARVIS" }

    override fun onResume() {
        super.onResume(); refresh()
        JarvisService.log = { m -> runOnUiThread { logText.text = m + "\n" + logText.text } }
    }
    override fun onPause() { JarvisService.log = null; super.onPause() }
}
