package com.jarvis.starter

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object OpenAIClient {
    private const val ENDPOINT = "https://api.openai.com/v1/responses"
    const val DEFAULT_MODEL = "gpt-5.6-luna"
    private var lastId: String? = null      // conversation memory (5 min)
    private var lastTime = 0L

    private fun post(key: String, body: JSONObject): JSONObject {
        val c = URL(ENDPOINT).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20_000; c.readTimeout = 60_000; c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw Exception("API error $code. Check API key and model name.")
        return JSONObject(text)
    }

    fun ask(ctx: Context, key: String, model: String, userName: String, text: String): String {
        return try {
            val instructions = """
                You are JARVIS, a witty, loyal, concise personal voice assistant for $userName, running on his Android phone.
                The user speaks Sinhala, English or a mix. ALWAYS reply in the language the user used (Sinhala script for Sinhala).
                Replies are spoken aloud: 1-2 short sentences, no markdown, no emojis.
                You have phone tools (calls, SMS, WhatsApp, apps, YouTube, maps, alarms, timers, flashlight, volume, media, battery, time).
                Use a tool whenever the user wants an action; never say you cannot if a tool exists.
                Only say an action is done if the tool result says so. For other questions, answer from knowledge.
            """.trimIndent()
            var input: Any = text
            var prev: String? = if (System.currentTimeMillis() - lastTime < 300_000) lastId else null
            repeat(5) {
                val body = JSONObject().put("model", model.ifBlank { DEFAULT_MODEL })
                    .put("instructions", instructions).put("input", input).put("tools", Tools.defs())
                if (prev != null) body.put("previous_response_id", prev)
                val resp = post(key, body)
                lastId = resp.optString("id"); lastTime = System.currentTimeMillis(); prev = lastId
                val out = resp.optJSONArray("output") ?: JSONArray()
                val results = JSONArray(); var answer = ""
                for (i in 0 until out.length()) {
                    val item = out.optJSONObject(i) ?: continue
                    when (item.optString("type")) {
                        "function_call" -> {
                            val args = JSONObject(item.optString("arguments", "{}").ifBlank { "{}" })
                            results.put(JSONObject().put("type", "function_call_output")
                                .put("call_id", item.optString("call_id"))
                                .put("output", Tools.run(ctx, item.optString("name"), args)))
                        }
                        "message" -> {
                            val cs = item.optJSONArray("content") ?: continue
                            for (j in 0 until cs.length()) {
                                val p = cs.optJSONObject(j) ?: continue
                                if (p.optString("type") == "output_text") answer += p.optString("text")
                            }
                        }
                    }
                }
                if (results.length() == 0) return answer.ifBlank { "Done." }
                input = results
            }
            "Done."
        } catch (e: Exception) { e.message ?: "Connection error" }
    }
}
