package com.jarvis.starter

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local command understanding: Sinhala + English. Returns a reply, or null to let the AI answer. */
object Brain {
    private val wakeWords = listOf("jarvis", "jarvish", "javis", "ජාවිස්", "ජාර්විස්", "ජාවිස")

    fun stripWake(text: String): String? {
        val l = text.lowercase(Locale.ROOT)
        for (w in wakeWords) {
            val i = l.indexOf(w)
            if (i >= 0) return l.substring(i + w.length).trim(' ', ',', '.', '!')
        }
        return null
    }

    fun isSinhala(t: String) = t.any { it in '\u0D80'..'\u0DFF' }
    private fun si(t: String, en: String, sin: String) = if (isSinhala(t)) sin else en

    private val filler = setOf(
        "please", "can", "you", "could", "for", "me", "to", "the", "a", "on", "in", "my", "app",
        "කරන්න", "කරපන්", "දාන්න", "දෙන්න", "ඉක්මනට", "එක", "එකේ", "එකෙන්", "ඇප්", "ඇප්එක"
    )
    private val callW = setOf("call", "dial", "ring", "කෝල්", "කෝල්එකක්", "අමතන්න", "ඇමතුම", "කතා")
    private val openW = setOf("open", "launch", "start", "ඕපන්", "විවෘත", "අරින්න", "ඇරපන්", "ඇරන්න", "ඔපන්")
    private val ytW = setOf("youtube", "යූටියුබ්", "යුටියුබ්", "යූ", "ටියුබ්", "play", "search", "ප්ලේ", "සර්ච්")
    private val alias = mapOf(
        "වට්සැප්" to "whatsapp", "වට්ස්ඇප්" to "whatsapp", "ෆේස්බුක්" to "facebook",
        "කැමරා" to "camera", "ගැලරි" to "gallery", "සෙටින්ග්ස්" to "settings", "ක්‍රෝම්" to "chrome",
        "මැප්ස්" to "maps", "ටෙලිග්‍රෑම්" to "telegram", "ඉන්ස්ටාග්‍රෑම්" to "instagram",
        "ටික්ටොක්" to "tiktok", "ගූගල්" to "google", "මැසේජ්" to "messages", "කැල්කියුලේටර්" to "calculator"
    )

    private fun words(t: String, vararg drop: Set<String>): String =
        t.split(Regex("[\\s,.!?]+")).filter { w -> w.isNotBlank() && drop.none { w in it } && w !in filler }
            .joinToString(" ")

    fun handle(ctx: Context, raw: String): String? {
        val t = raw.lowercase(Locale.ROOT).trim()
        fun has(vararg k: String) = k.any { t.contains(it) }
        return when {
            has("what time", "the time", "වේලාව", "වෙලාව") ->
                si(t, "The time is " + SimpleDateFormat("h:mm a", Locale.US).format(Date()),
                    "වේලාව දැන් " + SimpleDateFormat("h:mm a", Locale.US).format(Date()))

            has("youtube", "යූටියුබ්", "යුටියුබ්", "යූ ටියුබ්") -> {
                val q = words(t, callW, openW, ytW)
                val url = if (q.isBlank()) "https://www.youtube.com"
                else "https://www.youtube.com/results?search_query=" + Uri.encode(q)
                launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                if (q.isBlank()) si(t, "Opening YouTube.", "යූටියුබ් විවෘත කරනවා.")
                else si(t, "Searching YouTube for $q.", "යූටියුබ් එකේ $q සොයනවා.")
            }

            callW.any { t.contains(it) } -> {
                val who = words(t, callW, openW)
                if (who.isBlank()) return si(t, "Who should I call?", "කාටද කෝල් කරන්නේ?")
                val digits = who.replace(" ", "")
                val number = if (digits.matches(Regex("\\+?\\d{3,}"))) digits else findNumber(ctx, who)
                if (number == null) return si(t, "I couldn't find $who in your contacts.", "$who කොන්ටැක්ට්ස් වල හොයාගන්න බැහැ.")
                val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                launch(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                si(t, "Calling $who.", "$who ට කෝල් කරනවා.")
            }

            openW.any { t.contains(it) } -> {
                var n = words(t, openW)
                alias[n]?.let { n = it }
                if (n.isBlank()) return si(t, "Which app?", "කුමන ඇප් එකද?")
                val pm = ctx.packageManager
                val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val hit = pm.queryIntentActivities(main, 0)
                    .firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(n) }
                val li = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                if (li == null) si(t, "I couldn't find an app called $n.", "$n නමින් ඇප් එකක් හොයාගන්න බැහැ.")
                else { launch(ctx, li); si(t, "Opening $n.", "$n විවෘත කරනවා.") }
            }

            else -> null
        }
    }

    fun launch(ctx: Context, i: Intent) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    fun findNumber(ctx: Context, name: String): String? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val p = ContactsContract.CommonDataKinds.Phone
        ctx.contentResolver.query(p.CONTENT_URI, arrayOf(p.NUMBER),
            "${p.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }
}
