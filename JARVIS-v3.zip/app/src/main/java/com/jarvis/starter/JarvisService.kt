package com.jarvis.starter

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import kotlin.concurrent.thread

/** Always-on listener: say "Jarvis" (or "ජාවිස්"), JARVIS greets you by name, then give a command. */
class JarvisService : Service(), TextToSpeech.OnInitListener {
    companion object {
        var running = false
        var log: ((String) -> Unit)? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var commandMode = false
    private var speaking = true
    private lateinit var prefs: SharedPreferences
    private fun userName() = prefs.getString("name", "Niroshan").orEmpty().ifBlank { "Niroshan" }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = "jarvis"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "JARVIS", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("JARVIS is listening")
            .setContentText("Say \"Jarvis\"").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        running = true
        return START_STICKY
    }

    override fun onInit(status: Int) {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { h.post { speaking = false; listen() } }
            @Deprecated("deprecated") override fun onError(id: String?) { h.post { speaking = false; listen() } }
        })
        say("Hi ${userName()}, JARVIS is ready. Say Jarvis when you need me.")
    }

    private fun say(text: String) {
        log?.invoke("JARVIS: $text")
        speaking = true
        val t = tts ?: return
        val sinhala = Brain.isSinhala(text)
        val loc = if (sinhala) Locale("si", "LK") else Locale.US
        if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) t.language = loc else t.language = Locale.US
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun listen() {
        if (speaking || !running) return
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(res: Bundle?) {
                val list = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                if (!commandMode) {
                    val cmds = list.mapNotNull { Brain.stripWake(it) }
                    if (cmds.isEmpty()) { listen(); return }
                    val real = cmds.filter { it.isNotBlank() }
                    if (real.isEmpty()) { commandMode = true; say("Hi ${userName()}") }
                    else process(real)
                } else {
                    commandMode = false
                    if (list.isEmpty()) listen() else process(list)
                }
            }
            override fun onError(error: Int) {
                if (commandMode && (error == SpeechRecognizer.ERROR_NO_MATCH ||
                            error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) commandMode = false
                h.postDelayed({ listen() }, 700)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val lang = if (commandMode) prefs.getString("lang", "si-LK")!! else "en-US"
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        })
    }

    private fun process(cmds: List<String>) {
        log?.invoke("You: ${cmds.first()}")
        for (c in cmds) {
            val reply = Brain.handle(this, c)
            if (reply != null) { say(reply); return }
        }
        val key = prefs.getString("key", "").orEmpty()
        if (key.isBlank()) { say("Please save your API key first."); return }
        speaking = true
        thread {
            val ans = OpenAIClient.ask(applicationContext, key, prefs.getString("model", "").orEmpty(), userName(), cmds.first())
            h.post { say(ans) }
        }
    }

    override fun onDestroy() {
        running = false
        sr?.destroy()
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
